define(["require", "exports", "SeedModules.Features/modules/controllers/features"], function (require, exports) {
    "use strict";
    exports.__esModule = true;
});
//# sourceMappingURL=requires.js.map