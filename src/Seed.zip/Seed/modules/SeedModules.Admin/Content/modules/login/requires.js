define(["require", "exports", "SeedModules.Admin/modules/login/controllers/login"], function (require, exports) {
    "use strict";
    exports.__esModule = true;
});
//# sourceMappingURL=requires.js.map