import mod = require('SeedModules.Admin/modules/admin/module');

mod.controller('SeedModules.Admin/modules/admin/controllers/dashboard', [
  '$scope',
  function($scope) {}
]);
