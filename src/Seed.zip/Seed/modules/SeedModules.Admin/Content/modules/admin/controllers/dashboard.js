define(["require", "exports", "SeedModules.Admin/modules/admin/module"], function (require, exports, mod) {
    "use strict";
    exports.__esModule = true;
    mod.controller('SeedModules.Admin/modules/admin/controllers/dashboard', [
        '$scope',
        function ($scope) { }
    ]);
});
//# sourceMappingURL=dashboard.js.map