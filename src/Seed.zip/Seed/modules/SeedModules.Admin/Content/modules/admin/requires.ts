import 'SeedModules.Admin/modules/admin/directives/sidebar';
import 'SeedModules.Admin/modules/admin/directives/sidebarNav';
import 'SeedModules.Admin/modules/admin/controllers/admin';
import 'SeedModules.Admin/modules/admin/controllers/dashboard';
import 'SeedModules.Admin/modules/admin/controllers/users';
import 'SeedModules.Admin/modules/admin/controllers/roles';
import 'SeedModules.Admin/modules/admin/controllers/members';
import 'SeedModules.Admin/modules/admin/controllers/settings';
