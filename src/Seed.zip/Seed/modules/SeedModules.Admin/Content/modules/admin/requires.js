define(["require", "exports", "SeedModules.Admin/modules/admin/directives/sidebar", "SeedModules.Admin/modules/admin/directives/sidebarNav", "SeedModules.Admin/modules/admin/controllers/admin", "SeedModules.Admin/modules/admin/controllers/dashboard", "SeedModules.Admin/modules/admin/controllers/users", "SeedModules.Admin/modules/admin/controllers/roles", "SeedModules.Admin/modules/admin/controllers/members", "SeedModules.Admin/modules/admin/controllers/settings"], function (require, exports) {
    "use strict";
    exports.__esModule = true;
});
//# sourceMappingURL=requires.js.map