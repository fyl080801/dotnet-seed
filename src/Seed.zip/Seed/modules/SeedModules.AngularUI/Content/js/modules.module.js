define('SeedModules.AngularUI/modules/boot', [
    'require',
    'exports',
    'angular',
    'angular-ui-router',
    'schema-form-bootstrap',
    'angular-ui-tree'
], function (require, exports, angular) {
    'use strict';
    return angular.module('modules.angularui.boot', [
        'ui.bootstrap',
        'ui.tree',
        'schemaForm'
    ]);
});
define('SeedModules.AngularUI/modules/configs/httpConfig', ['SeedModules.AngularUI/modules/boot'], function (boot) {
    'use strict';
    boot.config([
        '$provide',
        '$httpProvider',
        function ($provide, $httpProvider) {
            $provide.decorator('app/factories/httpDataHandler', [
                '$delegate',
                '$rootScope',
                '$modal',
                '$appEnvironment',
                'app/services/popupService',
                function ($delegate, $rootScope, $modal, $appEnvironment, popupService) {
                    $delegate.doResponse = function (response, defer) {
                        if (response.config.dataOnly) {
                            defer.resolve(response.data, response);
                        } else if (response.data.success) {
                            defer.resolve(response.data.data, response);
                        } else {
                            $delegate.doError($.extend(response, { statusText: response.data.message }), defer);
                        }
                    };
                    $delegate.doError = function (response, defer) {
                        popupService.error(response.statusText);
                        defer.reject(response);
                    };
                    return $delegate;
                }
            ]);
        }
    ]);
});
define('SeedModules.AngularUI/modules/configs/location', ['SeedModules.AngularUI/modules/boot'], function (boot) {
    'use strict';
    boot.config([
        '$provide',
        function ($provide) {
            $provide.decorator('$location', [
                '$delegate',
                function ($delegate) {
                    $delegate.search = function (urlString) {
                        var pairs = (urlString || window.location.search).substring(1).split(/[&?]/);
                        var res = {}, i, pair;
                        for (i = 0; i < pairs.length; i++) {
                            pair = pairs[i].split('=');
                            if (pair[1])
                                res[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1]);
                        }
                        return res;
                    };
                    return $delegate;
                }
            ]);
        }
    ]);
});
define('SeedModules.AngularUI/modules/configs/ngTableDefaults', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/boot'
], function (require, exports, boot) {
    'use strict';
    exports.__esModule = true;
    var settings = JSON.parse(document.getElementById('seed-ui').getAttribute('data-site'));
    var ngTableDefaults = {
        options: {},
        schema: {},
        params: { count: settings.pageSize },
        settings: { counts: settings.pageCounts.split(/[,?]/) }
    };
    boot.value('SeedModules.AngularUI/modules/configs/ngTableDefaults', ngTableDefaults);
});
define('SeedModules.AngularUI/modules/configs/ngTableTemplates', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/boot'
], function (require, exports, boot) {
    'use strict';
    exports.__esModule = true;
    var RunClass = function () {
        function RunClass($templateCache) {
            $templateCache.put('ng-table/header.html', '<ng-table-sorter-row></ng-table-sorter-row>');
            $templateCache.put('ng-table/pager.html', '<div class="ng-cloak ng-table-pager clearfix" ng-if="params.data.length"> <div ng-if="params.settings().counts.length" class="ng-table-counts btn-group pull-right"> <button ng-repeat="count in params.settings().counts" type="button" ng-class="{\'active\':params.count()==count}" ng-click="params.count(count)" class="btn btn-default"> <span ng-bind="count"></span> </button> </div> <ul class="pagination ng-table-pagination"> <li ng-class="{\'disabled\': !page.active && !page.current, \'active\': page.current}" ng-repeat="page in pages" ng-switch="page.type"> <a ng-switch-when="prev" ng-click="params.page(page.number)" href="">&laquo;</a> <a ng-switch-when="first" ng-click="params.page(page.number)" href=""><span ng-bind="page.number"></span></a> <a ng-switch-when="page" ng-click="params.page(page.number)" href=""><span ng-bind="page.number"></span></a> <a ng-switch-when="more" ng-click="params.page(page.number)" href="">&#8230;</a> <a ng-switch-when="last" ng-click="params.page(page.number)" href=""><span ng-bind="page.number"></span></a> <a ng-switch-when="next" ng-click="params.page(page.number)" href="">&raquo;</a> </li> </ul> </div> ');
            $templateCache.put('ng-pager/pager.html', '<div class="ng-cloak ng-table-pager clearfix"> <div ng-if="params.settings().counts.length" class="ng-table-counts btn-group pull-right"> <button ng-repeat="count in params.settings().counts" type="button" ng-class="{\'active\':params.count()==count}" ng-click="params.count(count)" class="btn btn-default"> <span ng-bind="count"></span> </button> </div> <ul class="pagination ng-table-pagination"> <li ng-class="{\'disabled\': !page.active && !page.current, \'active\': page.current}" ng-repeat="page in pages" ng-switch="page.type"> <a ng-switch-when="prev" ng-click="params.page(page.number)" href="">&laquo;</a> <a ng-switch-when="first" ng-click="params.page(page.number)" href=""><span ng-bind="page.number"></span></a> <a ng-switch-when="page" ng-click="params.page(page.number)" href=""><span ng-bind="page.number"></span></a> <a ng-switch-when="more" ng-click="params.page(page.number)" href="">&#8230;</a> <a ng-switch-when="last" ng-click="params.page(page.number)" href=""><span ng-bind="page.number"></span></a> <a ng-switch-when="next" ng-click="params.page(page.number)" href="">&raquo;</a> </li> </ul> </div> ');
            $templateCache.put('ng-table/sorterRow.html', '<tr> <th title="{{$column.headerTitle(this)}}" ng-repeat="$column in $columns" ng-class="{ \'sortable\': $column.sortable(this), \'sort-asc\': params.sorting()[$column.sortable(this)]==\'asc\', \'sort-desc\': params.sorting()[$column.sortable(this)]==\'desc\' }" ng-click="sortBy($column, $event)" ng-if="$column.show(this)" ng-init="template=$column.headerTemplateURL(this)" class="header {{$column.class(this)}}"> <div ng-if="!template" class="ng-table-header" ng-class="{\'sort-indicator\': params.settings().sortingIndicator==\'div\'}"> <span ng-bind="$column.title(this)" ng-class="{\'sort-indicator\': params.settings().sortingIndicator==\'span\'}"></span> </div> <div ng-if="template" ng-include="template"></div> </th> </tr> ');
        }
        RunClass.$inject = ['$templateCache'];
        return RunClass;
    }();
    boot.run(RunClass);
});
define('SeedModules.AngularUI/modules/configs/schemaForm', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/boot',
    'angular'
], function (require, exports, boot, angular) {
    'use strict';
    exports.__esModule = true;
    var SchemaFormClass = function () {
        function SchemaFormClass(schemaFormDecoratorsProvider, schemaFormProvider, sfBuilderProvider, sfPathProvider) {
            var bootstrapDecorator = schemaFormDecoratorsProvider.decorator('bootstrapDecorator');
            var sfCompare = function (args) {
                if (args.form.compare) {
                    var ngModelElement = args.fieldFrag.querySelector('[ng-model]');
                    if (ngModelElement)
                        ngModelElement.setAttribute('sf-compare', '');
                }
            };
            angular.forEach(bootstrapDecorator, function (item, idx) {
                if (angular.isArray(item.builder)) {
                    item.builder.push(sfCompare);
                }
            });
        }
        return SchemaFormClass;
    }();
    var SchemaFormRun = function () {
        function SchemaFormRun($templateCache) {
        }
        return SchemaFormRun;
    }();
    SchemaFormClass.$inject = [
        'schemaFormDecoratorsProvider',
        'schemaFormProvider',
        'sfBuilderProvider',
        'sfPathProvider'
    ];
    SchemaFormRun.$inject = ['$templateCache'];
    boot.config(SchemaFormClass).run(SchemaFormRun);
});
define('SeedModules.AngularUI/modules/configs/form/simplecolor', [
    'SeedModules.AngularUI/modules/boot',
    'schema-form-bootstrap'
], function (boot) {
    'use strict';
    angular.module('schemaForm').config([
        'schemaFormDecoratorsProvider',
        'schemaFormProvider',
        'sfBuilderProvider',
        'sfPathProvider',
        function (schemaFormDecoratorsProvider, schemaFormProvider, sfBuilderProvider, sfPathProvider) {
            var base = '/SeedModules.AngularUI/modules/templates/';
            var simplecolor = function (name, schema, options) {
                if (schema.type === 'string' && schema.format == 'html') {
                    var f = schemaFormProvider.stdFormObj(name, schema, options);
                    f.key = options.path;
                    f.type = 'simplecolor';
                    options.lookup[sfPathProvider.stringify(options.path)] = f;
                    return f;
                }
            };
            schemaFormProvider.defaults.string.unshift(simplecolor);
            schemaFormDecoratorsProvider.addMapping('bootstrapDecorator', 'simplecolor', base + 'simplecolor.html');
            schemaFormDecoratorsProvider.createDirective('simplecolor', base + 'simplecolor.html');
        }
    ]);
});
define('SeedModules.AngularUI/modules/configs/enums/extendFormFields', [
    'require',
    'exports'
], function (require, exports) {
    'use strict';
    exports.__esModule = true;
    var ExtendFormFields;
    (function (ExtendFormFields) {
        ExtendFormFields['row'] = 'row';
        ExtendFormFields['column'] = 'column';
        ExtendFormFields['panel'] = 'panel';
        ExtendFormFields['container'] = 'container';
        ExtendFormFields['table'] = 'table';
        ExtendFormFields['switch'] = 'switch';
        ExtendFormFields['navbar'] = 'navbar';
    }(ExtendFormFields = exports.ExtendFormFields || (exports.ExtendFormFields = {})));
});
define('SeedModules.AngularUI/modules/configs/form/switchField', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/boot',
    'SeedModules.AngularUI/modules/configs/enums/extendFormFields'
], function (require, exports, boot, extendFormFields_1) {
    'use strict';
    exports.__esModule = true;
    var SwitchFieldConfig = function () {
        function SwitchFieldConfig(schemaFormDecoratorsProvider, schemaFormProvider, sfPathProvider) {
            var base = '/SeedModules.AngularUI/modules/templates/form/';
            var switchField = function (name, schema, options) {
                if (schema.type === 'boolean' && schema.format == 'html') {
                    var f = schemaFormProvider.stdFormObj(name, schema, options);
                    f.key = options.path;
                    f.type = extendFormFields_1.ExtendFormFields['switch'];
                    options.lookup[sfPathProvider.stringify(options.path)] = f;
                    return f;
                }
            };
            schemaFormProvider.defaults.boolean.push(switchField);
            schemaFormDecoratorsProvider.addMapping('bootstrapDecorator', extendFormFields_1.ExtendFormFields['switch'], base + 'switchField.html');
            schemaFormDecoratorsProvider.createDirective(extendFormFields_1.ExtendFormFields['switch'], base + 'switchField.html');
        }
        SwitchFieldConfig.$inject = [
            'schemaFormDecoratorsProvider',
            'schemaFormProvider',
            'sfPathProvider'
        ];
        return SwitchFieldConfig;
    }();
    boot.config(SwitchFieldConfig);
});
define('SeedModules.AngularUI/modules/configs/form/layout', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/boot',
    'SeedModules.AngularUI/modules/configs/enums/extendFormFields'
], function (require, exports, boot, extendFormFields_1) {
    'use strict';
    exports.__esModule = true;
    var base = '/SeedModules.AngularUI/modules/templates/form/';
    var RowConfig = function () {
        function RowConfig(schemaFormDecoratorsProvider, schemaFormProvider, sfPathProvider, sfBuilderProvider) {
            var layoutDefaults = [
                sfBuilderProvider.builders.sfField,
                sfBuilderProvider.builders.ngModelOptions,
                sfBuilderProvider.builders.condition,
                sfBuilderProvider.builders.transclusion
            ];
            schemaFormDecoratorsProvider.defineAddOn('bootstrapDecorator', extendFormFields_1.ExtendFormFields.row, base + 'row.html', layoutDefaults);
            schemaFormDecoratorsProvider.defineAddOn('bootstrapDecorator', extendFormFields_1.ExtendFormFields.column, base + 'column.html', layoutDefaults);
            schemaFormDecoratorsProvider.defineAddOn('bootstrapDecorator', extendFormFields_1.ExtendFormFields.navbar, base + 'navbar.html', layoutDefaults);
        }
        RowConfig.$inject = [
            'schemaFormDecoratorsProvider',
            'schemaFormProvider',
            'sfPathProvider',
            'sfBuilderProvider'
        ];
        return RowConfig;
    }();
    boot.config(RowConfig).run([
        '$templateCache',
        function ($templateCache) {
            $templateCache.put(base + 'row.html', '<div class="row" sf-field-transclude="items"></div>');
            $templateCache.put(base + 'column.html', '<div class="col-md-{{form.flex}} col-lg-{{form.flex}} col-sm-{{form.flex}} col-xs-{{flex}}" sf-field-transclude="items"></div>');
            $templateCache.put(base + 'navbar.html', '<div class="navbar navbar-{{form.theme}} {{form.htmlClass}}" style="margin: 0" sf-field-transclude="items"></div>');
            $templateCache.put('decorators/bootstrap/tabs.html', '<div ng-init="selected = { tab: 0 }" class="schema-form-tabs {{form.htmlClass}}"><ul class="nav nav-tabs"><li ng-repeat="tab in form.tabs" ng-disabled="form.readonly" ng-click="$event.preventDefault() || (selected.tab = $index)" ng-class="{active: selected.tab === $index}"><a href="#"> <i ng-if="tab.titleIcon && tab.titleIcon.length>0" class="{{tab.titleIcon}}"></i> {{ tab.title }}</a></li></ul><div class="tab-content {{form.fieldHtmlClass}}"></div></div>');
        }
    ]);
});
define('SeedModules.AngularUI/modules/configs/form/panel', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/boot',
    'SeedModules.AngularUI/modules/configs/enums/extendFormFields'
], function (require, exports, boot, extendFormFields_1) {
    'use strict';
    exports.__esModule = true;
    var base = '/SeedModules.AngularUI/modules/templates/form/';
    var PanelConfig = function () {
        function PanelConfig(schemaFormDecoratorsProvider, sfBuilderProvider) {
            var defaultBuilders = [
                sfBuilderProvider.builders.sfField,
                sfBuilderProvider.builders.ngModelOptions,
                sfBuilderProvider.builders.condition,
                sfBuilderProvider.builders.transclusion
            ];
            schemaFormDecoratorsProvider.defineAddOn('bootstrapDecorator', extendFormFields_1.ExtendFormFields.panel, base + 'panel.html', defaultBuilders);
            schemaFormDecoratorsProvider.defineAddOn('bootstrapDecorator', extendFormFields_1.ExtendFormFields.container, base + 'container.html', defaultBuilders);
        }
        PanelConfig.$inject = [
            'schemaFormDecoratorsProvider',
            'sfBuilderProvider'
        ];
        return PanelConfig;
    }();
    boot.config(PanelConfig).run([
        '$templateCache',
        function ($templateCache) {
            $templateCache.put(base + 'panel.html', '<div class="schema-form-panel panel panel-{{form.theme}} {{form.htmlClass}}"><div ng-if="!form.notitle" class="panel-heading"> <i ng-if="form.titleIcon && form.titleIcon.length>0" class="{{form.titleIcon}}"></i> <span ng-bind="form.title"></span></div><div sf-field-transclude="items"></div></div>');
            $templateCache.put(base + 'container.html', '<div class="panel-body {{form.htmlClass}}" sf-field-transclude="items"></div>');
        }
    ]);
});
define('SeedModules.AngularUI/modules/configs/form/table', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/boot',
    'SeedModules.AngularUI/modules/configs/enums/extendFormFields'
], function (require, exports, boot, extendFormFields_1) {
    'use strict';
    exports.__esModule = true;
    var base = '/SeedModules.AngularUI/modules/templates/form/';
    var PanelConfig = function () {
        function PanelConfig(schemaFormDecoratorsProvider, sfBuilderProvider) {
            var defaultBuilders = [
                sfBuilderProvider.builders.sfField,
                sfBuilderProvider.builders.ngModelOptions,
                sfBuilderProvider.builders.condition,
                sfBuilderProvider.builders.transclusion
            ];
            schemaFormDecoratorsProvider.defineAddOn('bootstrapDecorator', extendFormFields_1.ExtendFormFields.table, base + 'table.html', defaultBuilders);
        }
        PanelConfig.$inject = [
            'schemaFormDecoratorsProvider',
            'sfBuilderProvider'
        ];
        return PanelConfig;
    }();
    boot.config(PanelConfig).run([
        '$templateCache',
        function ($templateCache) {
            $templateCache.put(base + 'table.html', '<table class="table" ng-table-dynamic="form.tableParams with form.tableColumns"><tr ng-repeat="row in $data"><td ng-repeat="col in $columns">{{row[col.field]}}</td></tr></table>');
        }
    ]);
});
define('SeedModules.AngularUI/modules/providers/ngTableDefaultGetData', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/boot'
], function (require, exports, boot) {
    'use strict';
    exports.__esModule = true;
    var NgTableDefaultGetDataProvider = function () {
        function NgTableDefaultGetDataProvider() {
            this.filterFilterName = 'filter';
            this.sortingFilterName = 'orderBy';
            this.$get.$inject = ['$filter'];
        }
        NgTableDefaultGetDataProvider.prototype.$get = function ($filter) {
            return getData;
            function getData(data, params) {
                if (data == null) {
                    return [];
                }
                var fData = params.hasFilter() ? $filter(this.filterFilterName)(data, params.filter(true)) : data;
                var orderBy = params.orderBy();
                var orderedData = orderBy.length ? $filter(this.sortingFilterName)(fData, orderBy) : fData;
                var pagedData = orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count());
                params.total(orderedData.length);
                return pagedData;
            }
        };
        return NgTableDefaultGetDataProvider;
    }();
    boot.provider('SeedModules.AngularUI/modules/providers/ngTableDefaultGetData', NgTableDefaultGetDataProvider);
});
define('SeedModules.AngularUI/modules/configs/schemaFormDefaults', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/boot'
], function (require, exports, boot) {
    'use strict';
    exports.__esModule = true;
    var schemaFormDefaults = {
        schema: {},
        options: {
            validateOnRender: true,
            validationMessage: {
                0: '错误的类型: {{schema.type}} (应为 {{form.type}})',
                302: '{{title}} 不可为空',
                101: '值 {{viewValue}} 小于最小值 {{schema.minimum}}',
                103: '值 {{viewValue}} 大于最大值 {{schema.maximum}}',
                200: '字符串太短 (当前 {{viewValue.length}} 个字), 最小 {{schema.minLength}}',
                201: '字符串太长 (当前 {{viewValue.length}} 个字), 最大 {{schema.maxLength}}',
                202: '输入的格式不正确'
            }
        }
    };
    boot.value('SeedModules.AngularUI/modules/configs/schemaFormDefaults', schemaFormDefaults);
});
define('SeedModules.AngularUI/modules/module', [
    'require',
    'exports',
    'angular',
    'app/application',
    'SeedModules.AngularUI/modules/configs/httpConfig',
    'SeedModules.AngularUI/modules/configs/location',
    'SeedModules.AngularUI/modules/configs/ngTableDefaults',
    'SeedModules.AngularUI/modules/configs/ngTableTemplates',
    'SeedModules.AngularUI/modules/configs/schemaForm',
    'SeedModules.AngularUI/modules/configs/form/simplecolor',
    'SeedModules.AngularUI/modules/configs/form/switchField',
    'SeedModules.AngularUI/modules/configs/form/layout',
    'SeedModules.AngularUI/modules/configs/form/panel',
    'SeedModules.AngularUI/modules/configs/form/table',
    'SeedModules.AngularUI/modules/providers/ngTableDefaultGetData',
    'SeedModules.AngularUI/modules/configs/schemaFormDefaults'
], function (require, exports, angular) {
    'use strict';
    var RouteClass = function () {
        function RouteClass($provide, $appConfig) {
            var settings = JSON.parse(document.getElementById('seed-ui').getAttribute('data-site'));
            settings.prefix = settings.prefix ? '/' + settings.prefix : '';
            $appConfig.siteSettings = settings;
        }
        RouteClass.$inject = [
            '$provide',
            '$appConfig'
        ];
        return RouteClass;
    }();
    angular.module('template/modal/window.html', []).run([
        '$templateCache',
        function ($templateCache) {
            $templateCache.put('template/modal/window.html', '<div tabindex="-1" role="dialog" class="modal fade" ng-class="{in: animate}" ng-style="{\'z-index\': 1050 + index*10, display: \'block\'}" ng-click="close($event)">\n' + '    <div class="modal-dialog modal-{{size}}"><div class="modal-content" modal-transclude></div></div>\n' + '</div>');
        }
    ]);
    return angular.module('modules.angularui', ['modules.angularui.boot']).config(RouteClass);
});