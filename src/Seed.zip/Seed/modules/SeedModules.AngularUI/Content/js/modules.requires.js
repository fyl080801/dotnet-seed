define('SeedModules.AngularUI/modules/factories/ngTableColumn', [
    'require',
    'exports',
    'angular',
    'SeedModules.AngularUI/modules/module'
], function (require, exports, angular, mod) {
    'use strict';
    exports.__esModule = true;
    var defaults = {
        'class': function () {
            return '';
        },
        headerTemplateURL: function () {
            return false;
        },
        headerTitle: function () {
            return '';
        },
        sortable: function () {
            return false;
        },
        show: function () {
            return true;
        },
        title: function () {
            return '';
        },
        titleAlt: function () {
            return '';
        }
    };
    function ngTableColumnFactory() {
        function buildColumn(column, defaultScope) {
            var extendedCol = Object.create(column);
            for (var prop in defaults) {
                if (extendedCol[prop] === undefined) {
                    extendedCol[prop] = defaults[prop];
                }
                if (!angular.isFunction(extendedCol[prop])) {
                    (function (prop1) {
                        extendedCol[prop1] = function () {
                            return column[prop1];
                        };
                    }(prop));
                }
                (function (prop1) {
                    var getterFn = extendedCol[prop1];
                    extendedCol[prop1] = function () {
                        if (arguments.length === 0) {
                            return getterFn.call(column, defaultScope);
                        } else {
                            return getterFn.apply(column, arguments);
                        }
                    };
                }(prop));
            }
            return extendedCol;
        }
        return { buildColumn: buildColumn };
    }
    mod.factory('SeedModules.AngularUI/modules/factories/ngTableColumn', ngTableColumnFactory);
});
define('SeedModules.AngularUI/modules/factories/ngTableEventsChannel', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/module',
    'angular'
], function (require, exports, mod, angular) {
    'use strict';
    exports.__esModule = true;
    function ngTableEventsChannelFactory($rootScope) {
        var events = {};
        events = addChangeEvent('afterCreated', events);
        events = addChangeEvent('afterReloadData', events);
        events = addChangeEvent('datasetChanged', events);
        events = addChangeEvent('pagesChanged', events);
        return events;
        function addChangeEvent(eventName, target) {
            var fnName = eventName.charAt(0).toUpperCase() + eventName.substring(1);
            var event = {};
            event['on' + fnName] = createEventSubscriptionFn(eventName);
            event['publish' + fnName] = createPublishEventFn(eventName);
            return angular.extend(target, event);
        }
        function createEventSubscriptionFn(eventName) {
            return function subscription(handler) {
                var eventSelector = angular.identity;
                var scope = $rootScope;
                if (arguments.length === 2) {
                    if (angular.isFunction(arguments[1].$new)) {
                        scope = arguments[1];
                    } else {
                        eventSelector = arguments[1];
                    }
                } else if (arguments.length > 2) {
                    scope = arguments[1];
                    eventSelector = arguments[2];
                }
                if (angular.isObject(eventSelector)) {
                    var requiredPublisher = eventSelector;
                    eventSelector = function (publisher) {
                        return publisher === requiredPublisher;
                    };
                }
                return scope.$on('ngTable:' + eventName, function (event, params) {
                    if (params.isNullInstance)
                        return;
                    var eventArgs = rest(arguments, 2);
                    var fnArgs = [params].concat(eventArgs);
                    if (eventSelector.apply(this, fnArgs)) {
                        handler.apply(this, fnArgs);
                    }
                });
            };
        }
        function createPublishEventFn(eventName) {
            return function publish() {
                var fnArgs = ['ngTable:' + eventName].concat(Array.prototype.slice.call(arguments));
                $rootScope.$broadcast.apply($rootScope, fnArgs);
            };
        }
        function rest(array, n) {
            return Array.prototype.slice.call(array, n == null ? 1 : n);
        }
    }
    ngTableEventsChannelFactory.$inject = ['$rootScope'];
    mod.factory('SeedModules.AngularUI/modules/factories/ngTableEventsChannel', ngTableEventsChannelFactory);
});
define('SeedModules.AngularUI/modules/factories/ngTableGetDataBcShim', ['SeedModules.AngularUI/modules/module'], function (module) {
    'use strict';
    module.factory('SeedModules.AngularUI/modules/factories/ngTableGetDataBcShim', [
        '$q',
        function ($q) {
            return createWrapper;
            function createWrapper(getDataFn) {
                return function getDataShim() {
                    var $defer = $q.defer();
                    var pData = getDataFn.apply(this, [$defer].concat(Array.prototype.slice.call(arguments)));
                    if (!pData) {
                        pData = $defer.promise;
                    }
                    return pData;
                };
            }
        }
    ]);
});
define('SeedModules.AngularUI/modules/factories/ngTableParams', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/module',
    'angular'
], function (require, exports, mod, angular) {
    'use strict';
    exports.__esModule = true;
    function ngTableParamsFactory($q, $log, ngTableDefaults, ngTableGetDataBcShim, ngTableDefaultGetData, ngTableEventsChannel) {
        var isNumber = function (n) {
            return !isNaN(parseFloat(n)) && isFinite(n);
        };
        var ngTableParams = function (baseParameters, baseSettings) {
            var _this = this;
            if (typeof baseParameters === 'boolean') {
                this.isNullInstance = true;
            }
            var self = this, committedParams, isCommittedDataset = false, log = function (text, settings) {
                    if (settings && settings.debugMode && $log.debug) {
                        $log.debug.apply(_this, text);
                    }
                };
            this.data = [];
            this.parameters = function (newParameters, parseParamsFromUrl) {
                parseParamsFromUrl = parseParamsFromUrl || false;
                if (angular.isDefined(newParameters)) {
                    for (var key in newParameters) {
                        var value = newParameters[key];
                        if (parseParamsFromUrl && key.indexOf('[') >= 0) {
                            var keys = key.split(/\[(.*)\]/).reverse();
                            var lastKey = '';
                            for (var i = 0, len = keys.length; i < len; i++) {
                                var name = keys[i];
                                if (name !== '') {
                                    var v = value;
                                    value = {};
                                    value[lastKey = name] = isNumber(v) ? parseFloat(v) : v;
                                }
                            }
                            if (lastKey === 'sorting') {
                                params[lastKey] = {};
                            }
                            params[lastKey] = angular.extend(params[lastKey] || {}, value[lastKey]);
                        } else {
                            params[key] = isNumber(newParameters[key]) ? parseFloat(newParameters[key]) : newParameters[key];
                        }
                    }
                    log('ngTable: set parameters', params);
                    return this;
                }
                return params;
            };
            this.settings = function (newSettings) {
                if (angular.isDefined(newSettings)) {
                    if (angular.isArray(newSettings.data)) {
                        newSettings.total = newSettings.data.length;
                    }
                    if (newSettings.getData && newSettings.getData.length > 1) {
                        newSettings.getDataFnAdaptor = ngTableGetDataBcShim;
                    }
                    if (newSettings.getGroups && newSettings.getGroups.length > 2) {
                        newSettings.getGroupsFnAdaptor = ngTableGetDataBcShim;
                    }
                    var originalDataset = settings.data;
                    settings = angular.extend(settings, newSettings);
                    var hasDatasetChanged = newSettings.hasOwnProperty('data') && newSettings.data != originalDataset;
                    if (hasDatasetChanged) {
                        if (isCommittedDataset) {
                            this.page(1);
                        }
                        isCommittedDataset = false;
                        ngTableEventsChannel.publishDatasetChanged(this, newSettings.data, originalDataset);
                    }
                    log('ngTable: set settings', settings);
                    return this;
                }
                return settings;
            };
            this.page = function (page) {
                if (angular.isDefined(page)) {
                    return this.parameters({ page: page });
                } else {
                    return params.page;
                }
            };
            this.total = function (total) {
                if (angular.isDefined(total)) {
                    return this.settings({ total: total });
                } else {
                    return settings.total;
                }
            };
            this.count = function (count) {
                if (angular.isDefined(count)) {
                    return this.parameters({
                        count: count,
                        page: 1
                    });
                } else {
                    return params.count;
                }
            };
            this.filter = function (filter) {
                if (angular.isDefined(filter) && angular.isObject(filter)) {
                    return this.parameters({
                        filter: filter,
                        page: 1
                    });
                } else if (filter === true) {
                    var keys = Object.keys(params.filter);
                    var significantFilter = {};
                    for (var i = 0; i < keys.length; i++) {
                        var filterValue = params.filter[keys[i]];
                        if (filterValue != null && filterValue !== '') {
                            significantFilter[keys[i]] = filterValue;
                        }
                    }
                    return significantFilter;
                } else {
                    return params.filter;
                }
            };
            this.sorting = function (sorting) {
                if (arguments.length == 2) {
                    var sortArray = {};
                    sortArray[sorting] = arguments[1];
                    this.parameters({ sorting: sortArray });
                    return this;
                }
                return angular.isDefined(sorting) ? this.parameters({ sorting: sorting }) : params.sorting;
            };
            this.isSortBy = function (field, direction) {
                if (direction !== undefined) {
                    return angular.isDefined(params.sorting[field]) && params.sorting[field] == direction;
                } else {
                    return angular.isDefined(params.sorting[field]);
                }
            };
            this.orderBy = function () {
                var sorting = [];
                for (var column in params.sorting) {
                    sorting.push((params.sorting[column] === 'asc' ? '+' : '-') + column);
                }
                return sorting;
            };
            this.getData = function (params) {
                return ngTableDefaultGetData(this.data, params);
            };
            this.getGroups = function (column) {
                return runGetData().then(function (data) {
                    var groups = {};
                    angular.forEach(data, function (item) {
                        var groupName = angular.isFunction(column) ? column(item) : item[column];
                        groups[groupName] = groups[groupName] || { data: [] };
                        groups[groupName]['value'] = groupName;
                        groups[groupName].data.push(item);
                    });
                    var result = [];
                    for (var i in groups) {
                        result.push(groups[i]);
                    }
                    log('ngTable: refresh groups', result);
                    return result;
                });
            };
            this.generatePagesArray = function (currentPage, totalItems, pageSize, maxBlocks) {
                if (!arguments.length) {
                    currentPage = this.page();
                    totalItems = this.total();
                    pageSize = this.count();
                }
                var maxPage, maxPivotPages, minPage, numPages, pages;
                maxBlocks = maxBlocks && maxBlocks < 6 ? 6 : maxBlocks;
                pages = [];
                numPages = Math.ceil(totalItems / pageSize);
                if (numPages > 1) {
                    pages.push({
                        type: 'prev',
                        number: Math.max(1, currentPage - 1),
                        active: currentPage > 1
                    });
                    pages.push({
                        type: 'first',
                        number: 1,
                        active: currentPage > 1,
                        current: currentPage === 1
                    });
                    maxPivotPages = Math.round((settings.paginationMaxBlocks - settings.paginationMinBlocks) / 2);
                    minPage = Math.max(2, currentPage - maxPivotPages);
                    maxPage = Math.min(numPages - 1, currentPage + maxPivotPages * 2 - (currentPage - minPage));
                    minPage = Math.max(2, minPage - (maxPivotPages * 2 - (maxPage - minPage)));
                    var i = minPage;
                    while (i <= maxPage) {
                        if (i === minPage && i !== 2 || i === maxPage && i !== numPages - 1) {
                            pages.push({
                                type: 'more',
                                active: false
                            });
                        } else {
                            pages.push({
                                type: 'page',
                                number: i,
                                active: currentPage !== i,
                                current: currentPage === i
                            });
                        }
                        i++;
                    }
                    pages.push({
                        type: 'last',
                        number: numPages,
                        active: currentPage !== numPages,
                        current: currentPage === numPages
                    });
                    pages.push({
                        type: 'next',
                        number: Math.min(numPages, currentPage + 1),
                        active: currentPage < numPages
                    });
                }
                return pages;
            };
            this.isDataReloadRequired = function () {
                return !isCommittedDataset || !angular.equals(params, committedParams);
            };
            this.hasFilter = function () {
                return Object.keys(this.filter(true)).length > 0;
            };
            this.hasFilterChanges = function () {
                return !angular.equals(params && params.filter, committedParams && committedParams.filter);
            };
            this.url = function (asString) {
                asString = asString || false;
                var pairs = asString ? [] : {};
                for (var key in params) {
                    if (params.hasOwnProperty(key)) {
                        var item = params[key], name = encodeURIComponent(key);
                        if (typeof item === 'object') {
                            for (var subkey in item) {
                                if (!angular.isUndefined(item[subkey]) && item[subkey] !== '') {
                                    var pname = name + '[' + encodeURIComponent(subkey) + ']';
                                    if (asString) {
                                        pairs.push(pname + '=' + item[subkey]);
                                    } else {
                                        pairs[pname] = item[subkey];
                                    }
                                }
                            }
                        } else if (!angular.isFunction(item) && !angular.isUndefined(item) && item !== '') {
                            if (asString) {
                                pairs.push(name + '=' + encodeURIComponent(item));
                            } else {
                                pairs[name] = encodeURIComponent(item);
                            }
                        }
                    }
                }
                return pairs;
            };
            this.reload = function () {
                var self = this, pData = null;
                settings.$loading = true;
                committedParams = angular.copy(params);
                isCommittedDataset = true;
                if (settings.groupBy) {
                    pData = runInterceptorPipeline(runGetGroups);
                } else {
                    pData = runInterceptorPipeline(runGetData);
                }
                log('ngTable: reload data');
                var oldData = self.data;
                return pData.then(function (data) {
                    settings.$loading = false;
                    self.data = data;
                    ngTableEventsChannel.publishAfterReloadData(self, data, oldData);
                    self.reloadPages();
                    if (settings.$scope) {
                        settings.$scope.$emit('ngTableAfterReloadData');
                    }
                    return data;
                })['catch'](function (reason) {
                    committedParams = null;
                    isCommittedDataset = false;
                    return $q.reject(reason);
                });
            };
            this.reloadPages = function () {
                var currentPages;
                return function () {
                    var oldPages = currentPages;
                    var newPages = self.generatePagesArray(self.page(), self.total(), self.count());
                    if (!angular.equals(oldPages, newPages)) {
                        currentPages = newPages;
                        ngTableEventsChannel.publishPagesChanged(this, newPages, oldPages);
                    }
                };
            }();
            function runGetData() {
                var getDataFn = settings.getDataFnAdaptor(settings.getData);
                return $q.when(getDataFn.call(settings, self));
            }
            function runGetGroups() {
                var getGroupsFn = settings.getGroupsFnAdaptor(settings.getGroups);
                return $q.when(getGroupsFn.call(settings, settings.groupBy, self));
            }
            function runInterceptorPipeline(fetchFn) {
                var interceptors = settings.interceptors || [];
                return interceptors.reduce(function (result, interceptor) {
                    var thenFn = interceptor.response && interceptor.response.bind(interceptor) || $q.when;
                    var rejectFn = interceptor.responseError && interceptor.responseError.bind(interceptor) || $q.reject;
                    return result.then(function (data) {
                        return thenFn(data, self);
                    }, function (reason) {
                        return rejectFn(reason, self);
                    });
                }, fetchFn());
            }
            var params = {
                page: 1,
                count: 1,
                filter: {},
                sorting: {},
                group: {},
                groupBy: null
            };
            angular.extend(params, ngTableDefaults.params);
            var settings = {
                $scope: null,
                $loading: false,
                data: null,
                total: 0,
                defaultSort: 'desc',
                filterDelay: 750,
                counts: [
                    10,
                    25,
                    50,
                    100
                ],
                interceptors: [],
                paginationMaxBlocks: 11,
                paginationMinBlocks: 5,
                sortingIndicator: 'span',
                getDataFnAdaptor: angular.identity,
                getGroupsFnAdaptor: angular.identity,
                getGroups: this.getGroups,
                getData: this.getData
            };
            this.settings(ngTableDefaults.settings);
            this.settings(baseSettings);
            this.parameters(baseParameters, true);
            ngTableEventsChannel.publishAfterCreated(this);
            return this;
        };
        return ngTableParams;
    }
    ngTableParamsFactory.$inject = [
        '$q',
        '$log',
        'SeedModules.AngularUI/modules/configs/ngTableDefaults',
        'SeedModules.AngularUI/modules/factories/ngTableGetDataBcShim',
        'SeedModules.AngularUI/modules/providers/ngTableDefaultGetData',
        'SeedModules.AngularUI/modules/factories/ngTableEventsChannel'
    ];
    mod.factory('SeedModules.AngularUI/modules/factories/ngTableParams', ngTableParamsFactory);
});
define('SeedModules.AngularUI/modules/factories/ngTableRequest', ['SeedModules.AngularUI/modules/module'], function (module) {
    'use strict';
    module.factory('SeedModules.AngularUI/modules/factories/ngTableRequest', [
        '$location',
        'SeedModules.AngularUI/modules/factories/ngTableParams',
        'SeedModules.AngularUI/modules/services/requestService',
        function ($location, ngTableParams, requestService) {
            function getData(params, requestOptions) {
                var query = $location.search(requestOptions.url);
                var url = requestOptions.url.split(/[&?]/)[0];
                query.page = params.page();
                query.count = params.count();
                var queryArray = [];
                for (var n in query) {
                    queryArray.push(n + '=' + query[n]);
                }
                var urlString = [
                    url,
                    queryArray.join('&')
                ].join('?');
                return requestService.url(urlString).options(requestOptions).post($.extend({}, requestOptions.data)).result.then(function (result) {
                    if (result && result.total)
                        params.total(result.total);
                    return result.list;
                }, function () {
                    return [];
                });
            }
            return function (initOptions) {
                var self = this;
                var options = {};
                this.options = function (newOptions) {
                    if (angular.isDefined(newOptions)) {
                        angular.extend(options, newOptions);
                    }
                    return self;
                };
                this.ngTableParams = function (newParams, newSettings) {
                    return new ngTableParams(newParams, $.extend(newSettings, {
                        getData: function (params) {
                            return getData(params, options);
                        }
                    }));
                };
                this.options(initOptions);
                return this;
            };
        }
    ]);
});
define('SeedModules.AngularUI/modules/factories/schemaFormParams', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/module',
    'angular'
], function (require, exports, mod, angular) {
    'use strict';
    exports.__esModule = true;
    function schemaFormParamsFactory(schemaFormDefaults) {
        var _this = this;
        var schemaFormParams = function (baseSchema, baseOptions) {
            var self = _this;
            var formSchema = {
                type: 'object',
                properties: {},
                required: []
            };
            angular.extend(formSchema, schemaFormDefaults.schema);
            var options = {};
            _this.options = function (newOptions) {
                if (!angular.isDefined(newOptions)) {
                    return options;
                }
                angular.extend(options, newOptions);
                return self;
            };
            _this.schema = function (newSchema) {
                if (!angular.isDefined(newSchema)) {
                    return formSchema;
                }
                formSchema.type = newSchema.type || 'object';
                formSchema.properties = newSchema.properties || {};
                formSchema.required = newSchema.required || [];
                return self;
            };
            _this.properties = function (propertiesDefine) {
                var currentSchema = self.schema();
                if (!angular.isDefined(propertiesDefine)) {
                    return currentSchema.properties;
                }
                currentSchema.properties = propertiesDefine;
                angular.forEach(currentSchema.properties, function (item, key) {
                    self.required(key, item.required);
                });
                return self;
            };
            _this.property = function (propertyName, propertyDefine) {
                var currentSchema = self.schema();
                if (!angular.isDefined(propertyDefine)) {
                    return currentSchema.properties[propertyName];
                }
                currentSchema.properties[propertyName] = propertyDefine;
                self.required(propertyName, propertyDefine.required);
                return self;
            };
            _this.required = function (propertyName, isRequired) {
                var currentSchema = self.schema();
                var requiredIndex = currentSchema.required.indexOf(propertyName);
                if (!angular.isDefined(isRequired)) {
                    return requiredIndex >= 0;
                }
                if (isRequired && requiredIndex < 0) {
                    currentSchema.required.push(propertyName);
                } else if (requiredIndex >= 0) {
                    currentSchema.required.splice(requiredIndex, 1);
                }
                return self;
            };
            _this.options(schemaFormDefaults.options);
            _this.options(baseOptions);
            _this.schema(baseSchema);
            return _this;
        };
        return schemaFormParams;
    }
    exports.schemaFormParamsFactory = schemaFormParamsFactory;
    schemaFormParamsFactory.$inject = ['SeedModules.AngularUI/modules/configs/schemaFormDefaults'];
    mod.factory('SeedModules.AngularUI/modules/factories/schemaFormParams', schemaFormParamsFactory);
});
define('SeedModules.AngularUI/modules/factories/delayTimer', [
    'SeedModules.AngularUI/modules/module',
    'angular'
], function (module, angular) {
    'use strict';
    module.factory('SeedModules.AngularUI/modules/factories/delayTimer', [
        '$timeout',
        function ($timeout) {
            var delayFn = function (baseOptions) {
                var self = this;
                var timer = 0;
                var options = {
                    callback: angular.noop,
                    canceling: angular.noop,
                    timeout: 1024
                };
                this.options = function (opts) {
                    if (opts) {
                        options = $.extend(options, opts);
                        return self;
                    }
                    return options;
                };
                this.invoke = function () {
                    self.cancel();
                    timer = $timeout(function () {
                        options.callback();
                    }, options.timeout);
                };
                this.cancel = function () {
                    (options.canceling || angular.noop)();
                    $timeout.cancel(timer);
                };
                this.options(baseOptions);
                return this;
            };
            return delayFn;
        }
    ]);
});
define('SeedModules.AngularUI/modules/services/requestService', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/module',
    'angular'
], function (require, exports, mod, angular) {
    'use strict';
    exports.__esModule = true;
    var RequestContext = function () {
        function RequestContext(defer) {
            this.defer = defer;
            this.result = defer.promise;
        }
        RequestContext.prototype.cancel = function () {
            this.defer.resolve();
        };
        return RequestContext;
    }();
    var WebApi = function () {
        function WebApi($q, $http, $modal, $appConfig, httpDataHandler, options) {
            this.$q = $q;
            this.$http = $http;
            this.$modal = $modal;
            this.$appConfig = $appConfig;
            this.httpDataHandler = httpDataHandler;
            this.options = options;
        }
        WebApi.prototype.get = function () {
            return new RequestContext(this.resolveHttp('GET'));
        };
        WebApi.prototype.post = function (data) {
            return new RequestContext(this.resolveHttp('POST', data));
        };
        WebApi.prototype.put = function (data) {
            return new RequestContext(this.resolveHttp('PUT', data));
        };
        WebApi.prototype.patch = function (data) {
            return new RequestContext(this.resolveHttp('PATCH', data));
        };
        WebApi.prototype.drop = function () {
            return new RequestContext(this.resolveHttp('DELETE'));
        };
        WebApi.prototype.resolveHttp = function (method, data) {
            var _this = this;
            var defer = this.$q.defer();
            var configs = angular.extend({
                method: method,
                data: data,
                timeout: defer.promise
            }, this.options);
            configs.url = this.$appConfig.siteSettings.prefix + this.options.url;
            var loading = this.options.showLoading !== false ? this.$modal.open({
                templateUrl: '/SeedModules.AngularUI/modules/views/Loading.html',
                size: 'sm'
            }) : null;
            this.$http(configs).then(function (response) {
                if (response.status >= 400) {
                    _this.httpDataHandler.doError(response, defer);
                } else {
                    _this.httpDataHandler.doResponse(response, defer);
                }
            })['catch'](function (response) {
                _this.httpDataHandler.doError(response, defer);
            })['finally'](function () {
                if (loading)
                    loading.close();
            });
            return defer;
        };
        return WebApi;
    }();
    var WebApiContext = function () {
        function WebApiContext($q, $http, $modal, $appConfig, httpDataHandler, url) {
            this.$q = $q;
            this.$http = $http;
            this.$modal = $modal;
            this.$appConfig = $appConfig;
            this.httpDataHandler = httpDataHandler;
            this.url = url;
            this.options({ url: url });
        }
        WebApiContext.prototype.get = function () {
            return this.api.get();
        };
        WebApiContext.prototype.post = function (data) {
            return this.api.post(data);
        };
        WebApiContext.prototype.put = function (data) {
            return this.api.put(data);
        };
        WebApiContext.prototype.patch = function (data) {
            return this.api.patch(data);
        };
        WebApiContext.prototype.drop = function () {
            return this.api.drop();
        };
        WebApiContext.prototype.options = function (options) {
            this.api = new WebApi(this.$q, this.$http, this.$modal, this.$appConfig, this.httpDataHandler, angular.extend(options, { url: this.url }));
            return this;
        };
        return WebApiContext;
    }();
    var RequestService = function () {
        function RequestService($q, $http, $modal, $appConfig, httpDataHandler) {
            this.$q = $q;
            this.$http = $http;
            this.$modal = $modal;
            this.$appConfig = $appConfig;
            this.httpDataHandler = httpDataHandler;
        }
        RequestService.prototype.url = function (url) {
            return new WebApiContext(this.$q, this.$http, this.$modal, this.$appConfig, this.httpDataHandler, url);
        };
        RequestService.$inject = [
            '$q',
            '$http',
            '$modal',
            '$appConfig',
            'app/factories/httpDataHandler'
        ];
        return RequestService;
    }();
    mod.service('SeedModules.AngularUI/modules/services/requestService', RequestService);
});
define('SeedModules.AngularUI/modules/services/utility', ['SeedModules.AngularUI/modules/module'], function (module) {
    'use strict';
    module.service('SeedModules.AngularUI/modules/services/utility', [
        '$q',
        '$timeout',
        function ($q, $timeout) {
            function convertToTree(data, defer) {
                for (var i = 0; i < data.length; i++) {
                    var item1 = data[i];
                    delete item1[defer.childrenProperty];
                    delete item1.$parent;
                }
                var map = {};
                for (var j = 0; j < data.length; j++) {
                    var item2 = data[j];
                    map[item2[defer.keyProperty]] = defer.warp ? { $data: item2 } : item2;
                }
                var val = [];
                for (var k = 0; k < data.length; k++) {
                    var item3 = defer.warp ? { $data: data[k] } : data[k];
                    var parent = defer.warp ? map[item3.$data[defer.parentKeyProperty]] : map[item3[defer.parentKeyProperty]];
                    if (parent) {
                        item3.$parent = parent;
                        (parent[defer.childrenProperty] || (parent[defer.childrenProperty] = [])).push(item3);
                    } else {
                        val.push(item3);
                    }
                    defer.onEachFunction(k, item3);
                }
                return val;
            }
            function doEachTree(tree, defer) {
                for (var i in tree) {
                    defer.onEachFunction(tree[i]);
                    if (tree[i][defer.childrenProperty])
                        doEachTree(tree[i][defer.childrenProperty], defer);
                }
            }
            this.uid = function () {
                return Date.parse(new Date().toString()) / 1000 + '';
            };
            this.toTree = function (data, warp) {
                var defer = $q.defer();
                defer.childrenProperty = 'children';
                defer.keyProperty = 'value';
                defer.parentKeyProperty = 'parent';
                defer.warp = warp;
                defer.onEachFunction = function (idx, item) {
                };
                defer.promise.children = function (property) {
                    defer.childrenProperty = property;
                    return defer.promise;
                };
                defer.promise.key = function (property) {
                    defer.keyProperty = property;
                    return defer.promise;
                };
                defer.promise.parentKey = function (property) {
                    defer.parentKeyProperty = property;
                    return defer.promise;
                };
                defer.promise.onEach = function (fn) {
                    if ($.isFunction(fn)) {
                        defer.onEachFunction = fn;
                    }
                    return defer.promise;
                };
                $timeout(function () {
                    if (!data) {
                        defer.resolve([]);
                    } else {
                        defer.resolve(convertToTree(data, defer));
                    }
                });
                return defer.promise;
            };
            this.eachTree = function (tree) {
                var defer = $q.defer();
                defer.childrenProperty = 'children';
                defer.promise.children = function (property) {
                    defer.childrenProperty = property;
                    return defer.promise;
                };
                defer.promise.onEach = function (fn) {
                    if ($.isFunction(fn)) {
                        defer.onEachFunction = fn;
                    }
                    return defer.promise;
                };
                $timeout(function () {
                    defer.resolve(doEachTree(tree, defer));
                });
                return defer.promise;
            };
        }
    ]);
});
define('SeedModules.AngularUI/modules/directives/triggerInput', ['SeedModules.AngularUI/modules/module'], function (module) {
    'use strict';
    module.directive('triggerInput', [
        'SeedModules.AngularUI/modules/factories/delayTimer',
        function (delayTimer) {
            return {
                restrict: 'AE',
                replace: true,
                scope: {
                    ngModel: '=',
                    mark: '=',
                    callback: '&',
                    canceling: '&',
                    timeout: '@'
                },
                templateUrl: '/SeedModules.AngularUI/modules/templates/triggerInput.html',
                link: function (scope, element, attrs, ctl) {
                    var delayTrigger = new delayTimer({
                        callback: scope.callback || angular.noop,
                        canceling: scope.canceling || angular.noop,
                        timeout: scope.timeout ? scope.timeout : 2000
                    });
                    scope.modelChanged = function () {
                        delayTrigger.invoke();
                    };
                    scope.reset = function () {
                        scope.ngModel = '';
                        delayTrigger.invoke();
                    };
                }
            };
        }
    ]);
});
define('SeedModules.AngularUI/modules/directives/ajaxForm', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/module',
    'jquery-form'
], function (require, exports, mod) {
    'use strict';
    exports.__esModule = true;
    function ajaxFormDirective($q, $modal, $appConfig, httpDataHandler) {
        return {
            restrict: 'AE',
            scope: { ajaxForm: '=' },
            link: function (scope, element, attr, ctrl) {
                scope.ajaxForm = $.extend({
                    type: 'POST',
                    showLoading: true
                }, scope.ajaxForm);
                scope.ajaxForm.submit = function (options) {
                    var defer = $q.defer();
                    var loading = $modal.open({
                        templateUrl: '/SeedModules.AngularUI/modules/views/Loading.html',
                        size: 'sm'
                    });
                    var submitOptions = options ? $.extend(scope.ajaxForm, options) : scope.ajaxForm;
                    submitOptions.url = $appConfig.siteSettings.prefix + submitOptions.url;
                    submitOptions.success = function (responseText, statusText, xhr, form) {
                        httpDataHandler.doResponse({
                            data: '',
                            config: {
                                dataOnly: true,
                                url: $appConfig.siteSettings.prefix + scope.ajaxForm.url
                            }
                        }, defer);
                        loading.close();
                    };
                    submitOptions.error = function (response, statusText, responseText, form) {
                        httpDataHandler.doError({
                            data: '',
                            statusText: responseText,
                            config: {
                                dataOnly: true,
                                url: scope.ajaxForm.url
                            }
                        }, defer);
                        loading.close();
                    };
                    $(element)['ajaxSubmit'](submitOptions);
                    return defer.promise;
                };
            }
        };
    }
    ajaxFormDirective.$inject = [
        '$q',
        '$modal',
        '$appConfig',
        'app/factories/httpDataHandler'
    ];
    mod.directive('ajaxForm', ajaxFormDirective);
});
define('SeedModules.AngularUI/modules/directives/fileInput', ['SeedModules.AngularUI/modules/module'], function (module) {
    'use strict';
    module.directive('fileInput', [function () {
            return {
                restrict: 'AE',
                replace: true,
                template: '<input name="{{name}}" type="file">',
                scope: {
                    fileInput: '=',
                    name: '@',
                    fileChanged: '&',
                    fileClear: '&'
                },
                link: function (scope, element, attr, ctrl) {
                    var jqElement = $(element);
                    jqElement.on('change', function () {
                        scope.fileInput.fileName = jqElement.val();
                        scope.$apply();
                        (scope.fileChanged || angular.noop)();
                    });
                    scope.fileInput = $.extend({}, scope.fileInput);
                    scope.fileInput.open = function () {
                        jqElement.trigger('click');
                    };
                    scope.fileInput.clear = function () {
                        jqElement.val('');
                        scope.fileInput.fileName = '';
                        (scope.fileClear || angular.noop)();
                    };
                }
            };
        }]);
});
define('SeedModules.AngularUI/modules/directives/sfCompare', ['SeedModules.AngularUI/modules/module'], function (module) {
    'use strict';
    module.directive('sfCompare', [
        '$timeout',
        function ($timeout) {
            return {
                restrict: 'AC',
                require: 'ngModel',
                link: function (scope, element, attrs, ctrl) {
                    var form = scope.$eval(attrs.sfChanged);
                    ctrl.$viewChangeListeners.push(function () {
                        var validity = angular.isFunction(form.compare) ? form.compare(ctrl.$modelValue, scope.model, form) : scope.evalExpr(form.compare, {
                            modelValue: ctrl.$modelValue,
                            model: scope.model,
                            form: form
                        });
                        scope.ngModel.$setValidity('compare', validity === true);
                    });
                }
            };
        }
    ]);
});
define('SeedModules.AngularUI/modules/directives/ngPager', ['SeedModules.AngularUI/modules/module'], function (module) {
    'use strict';
    module.directive('ngPager', [function () {
            return {
                restrict: 'A',
                replace: false,
                scope: { pagerSource: '=ngPager' },
                template: '<div ng-table-pagination="pagerSource" template-url="\'ng-pager/pager.html\'"></div>'
            };
        }]);
});
define('SeedModules.AngularUI/modules/controllers/ngTable', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/module',
    'angular'
], function (require, exports, mod, angular) {
    'use strict';
    exports.__esModule = true;
    var NgTableController = function () {
        function NgTableController($scope, $timeout, $parse, $compile, $attrs, $element, ngTableParams, ngTableColumn, ngTableEventsChannel) {
            this.$scope = $scope;
            this.$timeout = $timeout;
            this.$parse = $parse;
            this.$compile = $compile;
            this.$attrs = $attrs;
            this.$element = $element;
            this.ngTableParams = ngTableParams;
            this.ngTableColumn = ngTableColumn;
            this.ngTableEventsChannel = ngTableEventsChannel;
            var isFirstTimeLoad = true;
            $scope.$filterRow = {};
            $scope.$loading = false;
            if (!$scope.hasOwnProperty('params')) {
                $scope.params = new ngTableParams(true);
            }
            $scope.params.settings().$scope = $scope;
            var delayFilter = function () {
                var timer = 0;
                return function (callback, ms) {
                    $timeout.cancel(timer);
                    timer = $timeout(callback, ms);
                };
            }();
            function onDataReloadStatusChange(newStatus) {
                if (!newStatus) {
                    return;
                }
                $scope.params.settings().$scope = $scope;
                var currentParams = $scope.params;
                if (currentParams.hasFilterChanges()) {
                    var applyFilter = function () {
                        currentParams.page(1);
                        currentParams.reload();
                    };
                    if (currentParams.settings().filterDelay) {
                        delayFilter(applyFilter, currentParams.settings().filterDelay);
                    } else {
                        applyFilter();
                    }
                } else {
                    currentParams.reload();
                }
            }
            $scope.$watch('params', function (newParams, oldParams) {
                if (newParams === oldParams || !newParams) {
                    return;
                }
                newParams.reload();
            }, false);
            $scope.$watch('params.isDataReloadRequired()', onDataReloadStatusChange);
            function commonInit() {
                ngTableEventsChannel.onAfterReloadData(bindDataToScope, $scope, isMyPublisher);
                ngTableEventsChannel.onPagesChanged(bindPagesToScope, $scope, isMyPublisher);
                function bindDataToScope(params, newDatapage) {
                    if (params.settings().groupBy) {
                        $scope.$groups = newDatapage;
                    } else {
                        $scope.$data = newDatapage;
                    }
                }
                function bindPagesToScope(params, newPages) {
                    $scope.pages = newPages;
                }
                function isMyPublisher(publisher) {
                    return $scope.params === publisher;
                }
            }
            commonInit();
        }
        NgTableController.prototype.compileDirectiveTemplates = function () {
            if (!this.$element.hasClass('ng-table')) {
                this.$scope.templates = {
                    header: this.$attrs.templateHeader || 'ng-table/header.html',
                    pagination: this.$attrs.templatePagination || 'ng-table/pager.html'
                };
                this.$element.addClass('ng-table');
                var headerTemplate = null;
                var theadFound = false;
                angular.forEach(this.$element.children(), function (e) {
                    if (e.tagName === 'THEAD') {
                        theadFound = true;
                    }
                });
                if (!theadFound) {
                    headerTemplate = angular.element(document.createElement('thead')).attr('ng-include', 'templates.header');
                    this.$element.prepend(headerTemplate);
                }
                var paginationTemplate = angular.element(document.createElement('div')).attr({
                    'ng-table-pagination': 'params',
                    'template-url': 'templates.pagination'
                });
                this.$element.after(paginationTemplate);
                if (headerTemplate) {
                    this.$compile(headerTemplate)(this.$scope);
                }
                this.$compile(paginationTemplate)(this.$scope);
            }
        };
        NgTableController.prototype.buildColumns = function (columns) {
            var _this = this;
            return columns.map(function (col) {
                return _this.ngTableColumn.buildColumn(col, _this.$scope);
            });
        };
        NgTableController.prototype.parseNgTableDynamicExpr = function (attr) {
            if (!attr || attr.indexOf(' with ') > -1) {
                var parts = attr.split(/\s+with\s+/);
                return {
                    tableParams: parts[0],
                    columns: parts[1]
                };
            } else {
                throw new Error('转换错误 (示例: ng-table-dynamic=\'tableParams with cols\')');
            }
        };
        NgTableController.prototype.setupBindingsToInternalScope = function (tableParamsExpr) {
            var _this = this;
            var tableParamsGetter = this.$parse(tableParamsExpr);
            this.$scope.$watch(tableParamsGetter, function (params) {
                if (angular.isUndefined(params)) {
                    return;
                }
                _this.$scope.paramsModel = tableParamsGetter;
                _this.$scope.params = params;
            }, false);
            if (this.$attrs.showFilter) {
                this.$scope.$parent.$watch(this.$attrs.showFilter, function (value) {
                    _this.$scope.show_filter = value;
                });
            }
            if (this.$attrs.disableFilter) {
                this.$scope.$parent.$watch(this.$attrs.disableFilter, function (value) {
                    _this.$scope.$filterRow.disabled = value;
                });
            }
        };
        NgTableController.$inject = [
            '$scope',
            '$timeout',
            '$parse',
            '$compile',
            '$attrs',
            '$element',
            'SeedModules.AngularUI/modules/factories/ngTableParams',
            'SeedModules.AngularUI/modules/factories/ngTableColumn',
            'SeedModules.AngularUI/modules/factories/ngTableEventsChannel'
        ];
        return NgTableController;
    }();
    exports.NgTableController = NgTableController;
    mod.controller('SeedModules.AngularUI/modules/controllers/ngTable', NgTableController);
});
define('SeedModules.AngularUI/modules/directives/ngTable', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/module',
    'angular',
    'SeedModules.AngularUI/modules/controllers/ngTable'
], function (require, exports, mod, angular, ngTable_1) {
    'use strict';
    exports.__esModule = true;
    function ngTableDirective($q, $parse) {
        return {
            restrict: 'A',
            priority: 1001,
            scope: true,
            controller: ngTable_1.NgTableController,
            compile: function (element) {
                var columns = [], i = 0, row = null;
                angular.forEach(angular.element(element.find('tr')), function (tr) {
                    tr = angular.element(tr);
                    if (!tr.hasClass('ng-table-group') && !row) {
                        row = tr;
                    }
                });
                if (!row) {
                    return;
                }
                angular.forEach(row.find('td'), function (item) {
                    var el = angular.element(item);
                    if (el.attr('ignore-cell') && 'true' === el.attr('ignore-cell')) {
                        return;
                    }
                    var getAttrValue = function (attr) {
                        return el.attr('x-data-' + attr) || el.attr('data-' + attr) || el.attr(attr);
                    };
                    var parsedAttribute = function (attr) {
                        var expr = getAttrValue(attr);
                        if (!expr) {
                            return undefined;
                        }
                        return function (scope, locals) {
                            return $parse(expr)(scope, angular.extend(locals || {}, { $columns: columns }));
                        };
                    };
                    var titleExpr = getAttrValue('title-alt') || getAttrValue('title');
                    if (titleExpr) {
                        el.attr('data-title-text', '{{' + titleExpr + '}}');
                    }
                    columns.push({
                        id: i++,
                        title: parsedAttribute('title'),
                        titleAlt: parsedAttribute('title-alt'),
                        headerTitle: parsedAttribute('header-title'),
                        sortable: parsedAttribute('sortable'),
                        'class': parsedAttribute('header-class'),
                        headerTemplateURL: parsedAttribute('header'),
                        show: function () {
                            if (el.attr('ng-if')) {
                                return function (scope) {
                                    return $parse(el.attr('ng-if'))(scope);
                                };
                            } else {
                                return undefined;
                            }
                        }()
                    });
                });
                return function (scope, element, attrs, controller) {
                    scope.$columns = columns = controller.buildColumns(columns);
                    controller.setupBindingsToInternalScope(attrs.ngTable);
                    controller.compileDirectiveTemplates();
                };
            }
        };
    }
    ngTableDirective.$inject = [
        '$q',
        '$parse'
    ];
    mod.directive('ngTable', ngTableDirective);
});
define('SeedModules.AngularUI/modules/directives/ngTableDynamic', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/module',
    'angular',
    'SeedModules.AngularUI/modules/controllers/ngTable'
], function (require, exports, mod, angular, ngTable_1) {
    'use strict';
    exports.__esModule = true;
    function ngTableDynamicDirective($parse) {
        return {
            restrict: 'A',
            priority: 1001,
            scope: true,
            controller: ngTable_1.NgTableController,
            compile: function (tElement) {
                var row;
                angular.forEach(angular.element(tElement.find('tr')), function (tr) {
                    tr = angular.element(tr);
                    if (!tr.hasClass('ng-table-group') && !row) {
                        row = tr;
                    }
                });
                if (!row) {
                    return;
                }
                angular.forEach(row.find('td'), function (item) {
                    var el = angular.element(item);
                    var getAttrValue = function (attr) {
                        return el.attr('x-data-' + attr) || el.attr('data-' + attr) || el.attr(attr);
                    };
                    var titleExpr = getAttrValue('title');
                    if (!titleExpr) {
                        el.attr('data-title-text', '{{$columns[$index].titleAlt(this) || $columns[$index].title(this)}}');
                    }
                    var showExpr = el.attr('ng-if');
                    if (!showExpr) {
                        el.attr('ng-if', '$columns[$index].show(this)');
                    }
                });
                return function (scope, element, attrs, controller) {
                    var expr = controller.parseNgTableDynamicExpr(attrs.ngTableDynamic);
                    controller.setupBindingsToInternalScope(expr.tableParams);
                    controller.compileDirectiveTemplates();
                    scope.$watchCollection(expr.columns, function (newCols) {
                        scope.$columns = controller.buildColumns(newCols);
                    });
                };
            }
        };
    }
    ngTableDynamicDirective.$inject = ['$parse'];
    mod.directive('ngTableDynamic', ngTableDynamicDirective);
});
define('SeedModules.AngularUI/modules/directives/ngTablePagination', ['SeedModules.AngularUI/modules/module'], function (module) {
    'use strict';
    module.directive('ngTablePagination', [
        '$compile',
        'SeedModules.AngularUI/modules/factories/ngTableEventsChannel',
        function ($compile, ngTableEventsChannel) {
            return {
                restrict: 'A',
                scope: {
                    params: '=ngTablePagination',
                    templateUrl: '='
                },
                replace: false,
                link: function (scope, element) {
                    ngTableEventsChannel.onAfterReloadData(function (pubParams) {
                        scope.pages = pubParams.generatePagesArray();
                    }, scope, function (pubParams) {
                        return pubParams === scope.params;
                    });
                    scope.$watch('templateUrl', function (templateUrl) {
                        if (angular.isUndefined(templateUrl)) {
                            return;
                        }
                        var template = angular.element(document.createElement('div'));
                        template.attr({ 'ng-include': 'templateUrl' });
                        element.append(template);
                        $compile(template)(scope);
                    });
                }
            };
        }
    ]);
});
define('SeedModules.AngularUI/modules/directives/ngTableSorterRow', ['SeedModules.AngularUI/modules/module'], function (module) {
    'use strict';
    module.directive('ngTableSorterRow', [function ngTableSorterRow() {
            var directive = {
                restrict: 'E',
                replace: true,
                templateUrl: 'ng-table/sorterRow.html',
                scope: true,
                controller: 'SeedModules.AngularUI/modules/controllers/ngTableSorterRow'
            };
            return directive;
        }]);
});
define('SeedModules.AngularUI/modules/directives/ngTree', ['SeedModules.AngularUI/modules/module'], function (module) {
    'use strict';
    module.directive('ngTree', [function () {
            return {
                restrict: 'EA',
                replace: true,
                templateUrl: function (element, attrs) {
                    if (attrs.rootTemplateUrl && attrs.rootTemplateUrl !== '') {
                        var fn = Function;
                        return new fn('return ' + attrs.rootTemplateUrl + ';')();
                    } else {
                        return '/SeedModules.AngularUI/modules/templates/ngTreeRoot.html';
                    }
                },
                scope: {
                    treeData: '=',
                    textField: '@',
                    iconField: '@',
                    childrenField: '@',
                    itemTemplateUrl: '=',
                    itemClicked: '&',
                    itemExpanding: '&',
                    itemInit: '&',
                    singleExpand: '='
                },
                controller: [
                    '$scope',
                    '$state',
                    'SeedModules.AngularUI/modules/services/utility',
                    function ($scope, $state, utility) {
                        $scope.$state = $state;
                        $scope.getItemText = function (item) {
                            return $scope.textField ? item[$scope.textField] : item.text;
                        };
                        $scope.getItemIcon = function (item) {
                            return $scope.iconField ? item[$scope.iconField] : item.icon;
                        };
                        $scope.getItemChildren = function (item) {
                            return $scope.childrenField ? item[$scope.childrenField] : item.children;
                        };
                        $scope.itemInited = function (item, $event) {
                            $scope.warpCallback('itemInit', item, $event);
                        };
                        $scope.isLeaf = function (item) {
                            var children = $scope.childrenField ? item[$scope.childrenField] : item.children;
                            return !children;
                        };
                        $scope.itemExpanded = function (item, $event) {
                            utility.eachTree($scope.treeData).children($scope.childrenField ? $scope.childrenField : 'children').onEach(function (child) {
                                if (child.$$hashKey !== item.$$hashKey) {
                                    child.$$isExpand = !$scope.signalExpand ? false : child.$$isExpand;
                                }
                            }).then(function () {
                                item.$$isExpand = !item.$$isExpand;
                                if (item.$$isExpand) {
                                    $scope.warpCallback('itemExpanding', item, $event);
                                }
                            });
                            $event.stopPropagation();
                        };
                        $scope.warpCallback = function (callback, item, $event) {
                            (item[callback] || $scope[callback] || angular.noop)({
                                $item: item,
                                $event: $event
                            });
                        };
                    }
                ]
            };
        }]);
});
define('SeedModules.AngularUI/modules/directives/stopPropagation', ['SeedModules.AngularUI/modules/module'], function (module) {
    'use strict';
    module.directive('stopPropagation', [function () {
            return {
                restrict: 'A',
                replace: false,
                link: function (scope, element, attr, ctrl) {
                }
            };
        }]);
});
define('SeedModules.AngularUI/modules/directives/tagInput', ['SeedModules.AngularUI/modules/module'], function (module) {
    'use strict';
    module.directive('tagInput', [function () {
            function getItemProperty(scope, property) {
                if (!property)
                    return undefined;
                if (angular.isFunction(scope.$parent[property]))
                    return scope.$parent[property];
                return function (item) {
                    return item[property];
                };
            }
            return {
                restrict: 'EA',
                scope: {
                    model: '=ngModel',
                    valueField: '@',
                    textField: '@',
                    classField: '@',
                    options: '=tagOptions',
                    disabled: '=ngDisabled',
                    textInput: '@',
                    placeholder: '@placeholder'
                },
                templateUrl: '/SeedModules.AngularUI/modules/templates/tagInput.html',
                replace: true,
                link: function (scope, element, attrs) {
                    scope.getText = function (tag) {
                        return tag[scope.textField || 'text'];
                    };
                    scope.getClass = function (tag) {
                        return tag[scope.classField || 'style'];
                    };
                    scope.getPlaceholder = function () {
                        return scope.placeholder && (!scope.model || scope.model.length <= 0) ? scope.placeholder : null;
                    };
                    scope.remove = function (tag) {
                    };
                }
            };
        }]);
});
define('SeedModules.AngularUI/modules/directives/tenantHref', ['SeedModules.AngularUI/modules/module'], function (module) {
    'use strict';
    module.directive('tenantHref', [
        '$appConfig',
        function ($appConfig) {
            return {
                restrict: 'A',
                replace: false,
                scope: { tenantHref: '@' },
                link: function (scope, element, attrs, ctl) {
                    $(element).attr('href', $appConfig.siteSettings.prefix + scope.tenantHref);
                }
            };
        }
    ]);
});
define('SeedModules.AngularUI/modules/directives/scrollspy', ['SeedModules.AngularUI/modules/module'], function (module) {
    'use strict';
    module.directive('scrollspy', [
        '$timeout',
        function ($timeout) {
            return {
                restrict: 'A',
                link: function (scope, element, attr, ctrl) {
                    element = $(element);
                    var content = element.children();
                    var elmHeight = element.height();
                    element.scroll(function () {
                        var scrollTop = element.scrollTop();
                        var offset = content.offset().top + content.height() - (scrollTop + elmHeight);
                        if (offset < parseInt(attr.offset)) {
                            scope.$broadcast('spyscrolled');
                        }
                    });
                }
            };
        }
    ]);
});
define('SeedModules.AngularUI/modules/filters/booleanText', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/module'
], function (require, exports, mod) {
    'use strict';
    exports.__esModule = true;
    mod.filter('booleanText', [function () {
            return function (val) {
                if (val === undefined || val === null || val === 0 || val === false || val === 'false' || val === 'False') {
                    return '否';
                } else {
                    return '是';
                }
            };
        }]);
});
define('SeedModules.AngularUI/modules/controllers/ngTableSorterRow', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/module'
], function (require, exports, mod) {
    'use strict';
    exports.__esModule = true;
    var NgTableSorterRowController = function () {
        function NgTableSorterRowController($scope) {
            this.$scope = $scope;
            $scope.sortBy = sortBy;
            function sortBy($column, event) {
                var parsedSortable = $column.sortable && $column.sortable();
                if (!parsedSortable) {
                    return;
                }
                var defaultSort = $scope.params.settings().defaultSort;
                var inverseSort = defaultSort === 'asc' ? 'desc' : 'asc';
                var sorting = $scope.params.sorting() && $scope.params.sorting()[parsedSortable] && $scope.params.sorting()[parsedSortable] === defaultSort;
                var sortingParams = event.ctrlKey || event.metaKey ? $scope.params.sorting() : {};
                sortingParams[parsedSortable] = sorting ? inverseSort : defaultSort;
                $scope.params.parameters({ sorting: sortingParams });
            }
        }
        NgTableSorterRowController.$inject = ['$scope'];
        return NgTableSorterRowController;
    }();
    mod.controller('SeedModules.AngularUI/modules/controllers/ngTableSorterRow', NgTableSorterRowController);
});
define('SeedModules.AngularUI/modules/requires', [
    'require',
    'exports',
    'SeedModules.AngularUI/modules/factories/ngTableColumn',
    'SeedModules.AngularUI/modules/factories/ngTableEventsChannel',
    'SeedModules.AngularUI/modules/factories/ngTableGetDataBcShim',
    'SeedModules.AngularUI/modules/factories/ngTableParams',
    'SeedModules.AngularUI/modules/factories/ngTableRequest',
    'SeedModules.AngularUI/modules/factories/schemaFormParams',
    'SeedModules.AngularUI/modules/factories/delayTimer',
    'SeedModules.AngularUI/modules/services/requestService',
    'SeedModules.AngularUI/modules/services/utility',
    'SeedModules.AngularUI/modules/directives/triggerInput',
    'SeedModules.AngularUI/modules/directives/ajaxForm',
    'SeedModules.AngularUI/modules/directives/fileInput',
    'SeedModules.AngularUI/modules/directives/sfCompare',
    'SeedModules.AngularUI/modules/directives/ngPager',
    'SeedModules.AngularUI/modules/directives/ngTable',
    'SeedModules.AngularUI/modules/directives/ngTableDynamic',
    'SeedModules.AngularUI/modules/directives/ngTablePagination',
    'SeedModules.AngularUI/modules/directives/ngTableSorterRow',
    'SeedModules.AngularUI/modules/directives/ngTree',
    'SeedModules.AngularUI/modules/directives/stopPropagation',
    'SeedModules.AngularUI/modules/directives/tagInput',
    'SeedModules.AngularUI/modules/directives/tenantHref',
    'SeedModules.AngularUI/modules/directives/scrollspy',
    'SeedModules.AngularUI/modules/filters/booleanText',
    'SeedModules.AngularUI/modules/controllers/ngTable',
    'SeedModules.AngularUI/modules/controllers/ngTableSorterRow'
], function (require, exports) {
    'use strict';
    exports.__esModule = true;
});