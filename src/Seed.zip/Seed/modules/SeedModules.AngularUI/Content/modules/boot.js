define(["require", "exports", "angular", "angular-ui-router", "schema-form-bootstrap", "angular-ui-tree"], function (require, exports, angular) {
    "use strict";
    return angular.module('modules.angularui.boot', [
        'ui.bootstrap',
        'ui.tree',
        'schemaForm'
    ]);
});
//# sourceMappingURL=boot.js.map