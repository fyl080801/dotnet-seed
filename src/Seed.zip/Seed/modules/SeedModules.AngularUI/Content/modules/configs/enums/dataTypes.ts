export enum DataTypes {
  string = 'string',
  number = 'number',
  integer = 'integer',
  boolean = 'boolean',
  object = 'object',
  array = 'array'
}
