export enum SchemaTypes {
  object = 'object'
}
