export enum ExtendFormFields {
  row = 'row',
  column = 'column',
  panel = 'panel',
  container = 'container',
  table = 'table',
  switch = 'switch',
  navbar = 'navbar'
}
