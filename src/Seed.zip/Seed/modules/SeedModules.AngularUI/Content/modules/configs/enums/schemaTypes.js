define(["require", "exports"], function (require, exports) {
    "use strict";
    exports.__esModule = true;
    var SchemaTypes;
    (function (SchemaTypes) {
        SchemaTypes["object"] = "object";
    })(SchemaTypes = exports.SchemaTypes || (exports.SchemaTypes = {}));
});
//# sourceMappingURL=schemaTypes.js.map