define('modules/ngtable/requires', [], function () {
    'use strict';
});