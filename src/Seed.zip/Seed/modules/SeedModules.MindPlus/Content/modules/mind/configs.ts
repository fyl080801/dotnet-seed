import angular = require('angular');

export = angular.module('modules.mindPlus.mind.configs', []);
