define(["require", "exports", "angular"], function (require, exports, angular) {
    "use strict";
    return angular.module('modules.mindPlus.mind.configs', []);
});
//# sourceMappingURL=configs.js.map