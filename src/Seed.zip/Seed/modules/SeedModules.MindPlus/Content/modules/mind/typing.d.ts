declare module 'kityminder';
