import 'SeedModules.MindPlus/modules/mind/factories/minderInstance';
import 'SeedModules.MindPlus/modules/mind/controllers/editor';
