define(["require", "exports", "SeedModules.MindPlus/modules/mind/factories/minderInstance", "SeedModules.MindPlus/modules/mind/controllers/editor"], function (require, exports) {
    "use strict";
    exports.__esModule = true;
});
//# sourceMappingURL=requires.js.map