define([
    'SeedModules.MindPlus/modules/admin/controllers/mindsettings'
], function () {
    'use strict';
});
//# sourceMappingURL=requires.js.map