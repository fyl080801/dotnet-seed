define([
  'SeedModules.MindPlus/modules/admin/controllers/mindsettings'
], function() {
  'use strict';

});
