define(['app/application'], function(application) {
  'use strict';

  return angular.module('modules.mindPlus.admin.configs', []);
});
