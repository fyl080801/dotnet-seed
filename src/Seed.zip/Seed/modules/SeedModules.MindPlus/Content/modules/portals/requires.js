define(["require", "exports", "SeedModules.MindPlus/modules/portals/controllers/index", "SeedModules.MindPlus/modules/portals/controllers/register"], function (require, exports) {
    "use strict";
    exports.__esModule = true;
});
//# sourceMappingURL=requires.js.map