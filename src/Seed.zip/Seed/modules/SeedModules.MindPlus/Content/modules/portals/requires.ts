import 'SeedModules.MindPlus/modules/portals/controllers/index';
import 'SeedModules.MindPlus/modules/portals/controllers/register';
