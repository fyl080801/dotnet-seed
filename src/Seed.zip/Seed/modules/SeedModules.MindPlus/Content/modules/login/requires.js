define(["require", "exports", "SeedModules.MindPlus/modules/login/controllers/login"], function (require, exports) {
    "use strict";
    exports.__esModule = true;
});
//# sourceMappingURL=requires.js.map