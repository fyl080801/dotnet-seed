import 'SeedModules.MindPlus/modules/login/controllers/login';
