define(["require", "exports", "angular", "app/application"], function (require, exports, angular) {
    "use strict";
    return angular.module('modules.wechat', []);
});
//# sourceMappingURL=module.js.map