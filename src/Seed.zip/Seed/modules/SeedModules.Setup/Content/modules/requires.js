define(['SeedModules.Setup/modules/controllers/form'], function () {
    'use strict';
});
//# sourceMappingURL=requires.js.map