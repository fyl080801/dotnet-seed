define(["require", "exports", "angular", "app/application", "SeedModules.PageBuilder/modules/providers/toolsBuilder", "SeedModules.PageBuilder/modules/configs/run"], function (require, exports, angular) {
    "use strict";
    return angular.module('modules.pagebuilder', ['modules.pagebuilder.boot']);
});
//# sourceMappingURL=module.js.map