define(["require", "exports", "angular", "schema-form-bootstrap"], function (require, exports, angular) {
    "use strict";
    return angular.module('modules.pagebuilder.boot', ['schemaForm']);
});
//# sourceMappingURL=boot.js.map