import angular = require('angular');
import 'schema-form-bootstrap';

export = angular.module('modules.pagebuilder.boot', ['schemaForm']);
