define(["require", "exports", "angular", "app/application"], function (require, exports, angular) {
    "use strict";
    return angular.module('modules.saas.configs', []);
});
//# sourceMappingURL=configs.js.map