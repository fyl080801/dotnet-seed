import angular = require('angular');
import 'app/application';
export = angular.module('modules.saas.configs', []);
