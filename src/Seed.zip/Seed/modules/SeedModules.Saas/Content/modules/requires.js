define(["require", "exports", "SeedModules.Saas/modules/controllers/tenants", "SeedModules.Saas/modules/controllers/projects", "SeedModules.Saas/modules/controllers/datasources", "SeedModules.Saas/modules/filters/tenantState"], function (require, exports) {
    "use strict";
    exports.__esModule = true;
});
//# sourceMappingURL=requires.js.map