define(['SeedModules.Saas/modules/module'], function(module) {
  'use strict';

  module.controller('SeedModules.Saas/modules/controllers/projects', [
    '$scope',
    function($scope) {}
  ]);
});
