import 'SeedModules.SqlBuilder/modules/controllers/manage';
