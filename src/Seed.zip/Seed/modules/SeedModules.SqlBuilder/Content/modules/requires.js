define(["require", "exports", "SeedModules.SqlBuilder/modules/controllers/manage"], function (require, exports) {
    "use strict";
    exports.__esModule = true;
});
//# sourceMappingURL=requires.js.map